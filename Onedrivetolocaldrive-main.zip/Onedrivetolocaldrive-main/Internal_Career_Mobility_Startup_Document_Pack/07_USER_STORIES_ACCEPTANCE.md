# User Stories & Acceptance Criteria

## HR
As HR, I want to upload employee data so that I can search internal talent.

Acceptance:
- invalid files are rejected safely
- schema errors are explained
- no data is exposed across organizations

## HR
As HR, I want to enter an open role so that I can find internal candidates.

Acceptance:
- role requirements are structured
- candidates are ranked
- each recommendation shows evidence and gaps
- ranking is reproducible for the same input/version

## Employee
As an employee, I want to see realistic next roles so that I know how to progress.

Acceptance:
- recommendations are evidence-based
- gaps are visible
- the system does not claim guaranteed promotion

## HR
As HR, I want promotion criteria to be versioned.

Acceptance:
- every decision references the criteria version used
- changes do not silently rewrite historical decisions

## Reviewer
As a reviewer, I want to understand why a decision was flagged.

Acceptance:
- the system displays the criteria, evidence, rule, and reason for flagging
- the system does not label a person as biased without a defined validated methodology

## Admin
As an admin, I want an audit trail.

Acceptance:
- important actions are timestamped
- actor identity is recorded
- audit events cannot be casually edited/deleted
