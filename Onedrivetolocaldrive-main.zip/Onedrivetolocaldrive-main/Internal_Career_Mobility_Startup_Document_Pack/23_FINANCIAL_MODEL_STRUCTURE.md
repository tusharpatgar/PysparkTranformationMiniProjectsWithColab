# Financial Model Structure

## Revenue
- number of customers
- average contract value
- pilot revenue
- recurring revenue
- expansion revenue
- churn

## COGS
- cloud
- AI/model usage
- storage
- support
- customer onboarding

## Operating expenses
- founder salary
- engineering
- sales
- marketing
- legal
- accounting
- security/compliance

## Key SaaS metrics
- ARR
- MRR
- gross margin
- CAC
- LTV
- churn
- net revenue retention
- payback period

## Early-stage focus
Before sophisticated SaaS metrics, track:
- interviews
- demos
- pilots
- paid pilots
- conversion
- time to value
- customer ROI
