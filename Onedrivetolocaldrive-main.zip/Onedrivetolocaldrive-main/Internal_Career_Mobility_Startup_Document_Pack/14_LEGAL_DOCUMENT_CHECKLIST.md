# Legal & Compliance Document Checklist

## Pre-company / founder
- Founder agreement
- Founder equity/cap table
- IP assignment
- Confidentiality agreements
- Contractor agreements
- Employment agreements
- invention/IP assignment where applicable

## Website/product
- Terms of Service
- Privacy Policy
- Cookie/technology notice if applicable
- Acceptable Use Policy
- AI Use Policy
- Security/Trust page

## Enterprise customer
- Master Services Agreement
- Order Form
- Data Processing Agreement
- Security Addendum
- Subprocessor list
- SLA
- Support terms
- Data deletion/return terms
- confidentiality provisions
- IP ownership/licensing provisions

## Privacy/data
- Data inventory
- Data flow map
- Data classification policy
- retention schedule
- deletion procedure
- data rights/grievance procedure
- incident/breach response
- DPIA or equivalent risk assessment where appropriate
- records of processing where appropriate

## AI governance
- AI system inventory
- model cards/internal model records
- intended-use statement
- prohibited-use statement
- evaluation report
- fairness/bias testing report
- human oversight procedure
- model-change log
- incident process

## Important
These are a checklist for professional review, not ready-to-sign legal instruments. Engage an India-qualified lawyer/privacy professional before production customer deployment.
