# Customer Discovery Plan

## Target interview groups
- 10 HR/People leaders
- 5 Talent Acquisition/Internal Mobility professionals
- 5 managers
- 10 employees

## Target company profile
Initial hypothesis:
- 500–5,000 employees
- Indian technology, SaaS, GCC, IT services, consulting, or BPO/ITES organizations
- Multiple departments and recurring internal hiring
- Existing HRIS/ATS/performance process

## Employee interview questions
1. Tell me about the last promotion or internal-transfer decision you experienced.
2. What criteria were you told mattered?
3. What seemed to matter in practice?
4. How transparent was the decision?
5. Did you receive a useful explanation?
6. Have you ever wanted to move teams and been unable to?
7. What role did your manager play?
8. Have you seen less-qualified people receive opportunities?
9. Did any experience contribute to considering resignation?
10. What would have made the process feel fairer?

## HR interview questions
1. How are promotions currently decided?
2. How are internal candidates identified?
3. How are promotion criteria documented?
4. How do you track internal applications?
5. How do you handle manager objections to transfers?
6. Can you reconstruct why an employee was rejected six months later?
7. How do you identify inconsistent manager assessments?
8. What percentage of open roles are filled internally?
9. What data exists in your HRIS/ATS/LMS/performance systems?
10. What would you pay to solve this problem?

## Interview rule
Do not pitch the product during the first half. Learn the current workflow before revealing the proposed solution.

## Discovery output
Every interview must produce:
- exact problem
- current workaround
- frequency
- consequence
- buyer
- existing budget
- willingness to pilot
- objections
