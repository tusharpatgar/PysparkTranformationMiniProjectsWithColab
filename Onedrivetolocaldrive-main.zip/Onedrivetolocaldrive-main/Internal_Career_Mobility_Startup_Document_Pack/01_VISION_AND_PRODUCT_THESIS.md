# Vision & Product Thesis

## Vision
Make internal career movement inside companies more transparent, evidence-based, explainable, and measurable.

## Problem
Employees can miss internal opportunities because organizations may have poor visibility into skills, inconsistent promotion criteria, manager-dependent mobility, talent hoarding, weak documentation, or fragmented HR data.

Companies can simultaneously lose internal talent, spend unnecessarily on external hiring, and struggle to explain why career decisions were made.

## Product
A workforce intelligence platform with four core capabilities:

1. **Talent Intelligence** — understand capabilities and evidence.
2. **Internal Mobility** — identify employees for open roles/projects.
3. **Career & Promotion Readiness** — show paths, gaps, and evidence.
4. **Decision Governance** — record criteria, evidence, rationale, review, and overrides.

## Differentiation hypothesis
Do not compete as a generic AI talent marketplace. Investigate a sharper wedge:
**evidence-backed internal career decisions**.

## Product promise
Before an organization hires externally or makes an internal career decision, the platform helps answer:
- Who internally could do this?
- Why are they qualified?
- What gaps remain?
- What evidence supports the decision?
- Was the defined process followed?
- What requires human review?

## Non-promises
The product does not:
- guarantee fairness;
- determine whether a person is biased;
- make final employment decisions;
- guarantee legal protection;
- prevent lawsuits;
- guarantee retention.

## Success hypothesis
If a company can identify qualified internal candidates faster, improve internal fill rates, document career decisions better, and surface process inconsistencies, HR leadership will pay for the product.
