# 90-Day Execution Plan

## Days 1–15 — Learn
- [ ] competitor teardown
- [ ] 20–30 employee interviews
- [ ] 10 HR/manager interviews
- [ ] problem evidence matrix
- [ ] ICP decision

## Days 16–30 — Define
- [ ] product thesis
- [ ] MVP PRD
- [ ] user stories
- [ ] data model
- [ ] architecture
- [ ] risk register
- [ ] prototype UX

## Days 31–45 — Build
- [ ] synthetic employee dataset
- [ ] employee import
- [ ] role import
- [ ] skill extraction
- [ ] matching
- [ ] evidence display
- [ ] career path
- [ ] basic readiness
- [ ] decision ledger

## Days 46–60 — Test
- [ ] expert evaluation
- [ ] matching accuracy
- [ ] explanation quality
- [ ] security tests
- [ ] adversarial tests
- [ ] user testing

## Days 61–75 — Sell
- [ ] demo
- [ ] pilot proposal
- [ ] ROI model
- [ ] 20 target accounts
- [ ] discovery calls
- [ ] 3 serious prospects

## Days 76–90 — Pilot
- [ ] signed pilot
- [ ] approved data scope
- [ ] controlled deployment
- [ ] weekly review
- [ ] measure ROI
- [ ] paid conversion discussion

## 90-day success
The goal is not “finished SaaS.”
The goal is:
**one validated painful problem + one real design partner + one paid pilot or a clear reason to pivot.**
