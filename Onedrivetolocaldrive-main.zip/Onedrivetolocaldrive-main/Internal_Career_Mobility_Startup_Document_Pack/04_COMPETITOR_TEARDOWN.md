# Competitor Teardown

## Research targets
- Gloat
- Fuel50
- Eightfold
- Workday
- SAP SuccessFactors
- Oracle HCM
- Phenom
- Lattice
- Cornerstone
- Darwinbox
- SKILWI
- Benevolve
- relevant Indian HRMS/talent platforms

## Required fields

| Competitor | ICP | Internal mobility | Career paths | Promotion/readiness | Skills intelligence | Decision audit | Integrations | AI | Pricing/positioning | Weakness | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|

## Questions
1. What exact problem do they sell?
2. Who buys?
3. What is the deployment model?
4. What data must the customer provide?
5. How do they infer skills?
6. How do they explain recommendations?
7. Can employees see their own profile and gaps?
8. Can managers influence/override recommendations?
9. Is there an auditable decision history?
10. How do they address privacy and AI risk?
11. What do customers complain about?
12. What is their strongest moat?
13. What would be expensive for us to replicate?

## Strategic conclusion
Do not compete feature-for-feature. Identify one workflow where existing systems are weak and buyers have a measurable problem.
