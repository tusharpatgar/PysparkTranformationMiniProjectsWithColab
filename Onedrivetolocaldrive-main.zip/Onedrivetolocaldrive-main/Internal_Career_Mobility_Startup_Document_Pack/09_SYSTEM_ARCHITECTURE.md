# System Architecture — MVP

## Suggested stack
- Frontend: Next.js + Tailwind
- Backend: Python/FastAPI
- Database: PostgreSQL
- Vector search: pgvector
- File storage: managed object storage
- Authentication: managed identity provider
- AI: LLM API + deterministic business rules
- Deployment: managed cloud services

## Architecture principle
Start as a modular monolith. Do not create microservices unless scale or team boundaries require them.

## Logical flow

User
→ Authentication
→ API
→ Authorization
→ Domain services
→ PostgreSQL / object storage
→ AI processing layer
→ validation/rules
→ human review
→ audit event

## AI boundary
AI may:
- extract skills
- summarize evidence
- semantically match
- generate explanations
- suggest gaps

Rules must control:
- eligibility
- thresholds
- workflow state
- authorization
- approval requirements
- audit events

Humans control:
- final promotion
- final transfer
- final hiring
- exceptions

## Production requirement
No customer employee data should be sent to an external model provider unless the contractual, privacy, security, retention, and data-processing arrangements are approved.
