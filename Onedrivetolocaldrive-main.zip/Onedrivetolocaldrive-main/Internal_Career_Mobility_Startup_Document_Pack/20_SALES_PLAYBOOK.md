# Sales Playbook

## Positioning
Do not lead with:
“AI promotion system.”

Lead with:
**“Evidence-based internal career mobility and decision intelligence.”**

## Discovery opening
“We are researching how companies decide whether employees are ready for internal roles and promotions. I want to understand your current process before showing anything.”

## Demo flow
1. Show open role.
2. Show internal candidates.
3. Explain evidence.
4. Show gaps.
5. Show career path.
6. Show promotion criteria.
7. Show decision ledger.
8. Show review trigger.
9. Show ROI.

## Objection: “We already have an HRMS.”
Response:
“Good. We are not trying to replace it. We are testing whether a focused decision layer can use your existing data to improve internal mobility and explainability.”

## Objection: “AI bias concerns.”
Response:
“The system is designed as decision support. It does not make final employment decisions. Recommendations are evidence-linked, criteria are versioned, and important decisions can require human review.”

## Objection: “Data privacy.”
Response:
“Privacy and security are part of the implementation design. We can begin with synthetic/anonymized data and only move to production data after the contractual and security review.”

## Sales rule
Never promise legal immunity or guaranteed fairness.
