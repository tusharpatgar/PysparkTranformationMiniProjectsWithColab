# Pricing & Business Model

## Pricing hypotheses to test
### Pilot
Fixed fee for a defined scope.

### SaaS
Possible models:
- per employee/month
- annual platform fee
- module-based pricing
- tiered workforce bands
- enterprise custom pricing

## Initial packaging
### Mobility
Internal candidate matching and career opportunities.

### Career
Career paths, skill gaps, readiness.

### Governance
Decision ledger, auditability, process analytics.

## Pricing validation
Ask prospects:
- What does the problem cost today?
- What budget owns it?
- What would a successful pilot be worth?
- What procurement threshold matters?
- Would they prefer annual or pilot-to-contract?

Do not anchor on unsupported market pricing.
