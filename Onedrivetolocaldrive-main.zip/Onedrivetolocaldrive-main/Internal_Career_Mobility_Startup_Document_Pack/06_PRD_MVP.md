# Product Requirements Document — MVP

## Product name
Working name: Internal Career Intelligence

## Objective
Prove that the system can identify internal candidates for open roles and explain readiness/gaps using evidence.

## MVP users
- HR administrator
- HR/talent professional
- Employee

## MVP workflows

### Workflow 1 — Import
HR uploads:
- employee CSV
- role/job descriptions
- skill taxonomy
- promotion criteria

### Workflow 2 — Employee profile
Show:
- role
- experience
- skills
- evidence
- projects
- career interests
- recommended opportunities

### Workflow 3 — Role matching
HR enters/selects a role.
System returns:
- candidate list
- match/readiness
- matched evidence
- missing skills
- confidence
- explanation

### Workflow 4 — Career path
Employee selects target role.
System shows:
- current capability
- required capability
- gaps
- recommended projects/learning
- evidence needed

### Workflow 5 — Promotion readiness
HR defines role-level criteria.
System maps available evidence to each criterion.
Output:
- met
- partially met
- missing evidence
- not evaluated

### Workflow 6 — Decision ledger
Record:
- employee
- role
- criteria version
- evidence references
- assessment
- decision
- reason
- reviewer
- timestamp
- override

## Out of scope
- payroll
- attendance
- surveillance
- automatic promotion decisions
- automatic termination
- private message monitoring
- production HRIS integrations
- sensitive attribute inference

## MVP success metrics
- >80% of test role matches judged useful by expert reviewers
- explanations trace to source evidence
- no critical authorization defects
- at least 2 design partners willing to test
- at least 1 paid pilot
