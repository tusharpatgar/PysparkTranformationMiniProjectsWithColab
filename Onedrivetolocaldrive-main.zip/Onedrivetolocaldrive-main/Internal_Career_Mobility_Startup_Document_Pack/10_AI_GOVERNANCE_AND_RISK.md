# AI Governance & Risk Register

## Product principle
AI is decision support, not the final employment decision-maker.

## High-risk scenarios
- incorrect skill inference
- hallucinated evidence
- biased recommendations
- inconsistent scoring
- proxy discrimination
- sensitive data leakage
- manager gaming
- automation bias
- employee misunderstanding
- customer misuse

## Risk register

| Risk | Severity | Mitigation | Test |
|---|---|---|---|
| Wrong skill inferred | High | evidence-linked inference | expert evaluation |
| Hallucinated evidence | Critical | source-grounded output | citation checks |
| Proxy bias | Critical | feature review + fairness tests | controlled test sets |
| Model drift | High | versioning + monitoring | regression suite |
| Automation bias | High | human review + UI warnings | usability test |
| Manager gaming | High | audit + versioned criteria | adversarial testing |
| Data leakage | Critical | tenant isolation + access controls | security testing |
| Wrong explanation | High | deterministic evidence mapping | explanation tests |

## Prohibited MVP behavior
- automatic promotion
- automatic rejection solely from an AI score
- automatic termination
- inference of sensitive attributes
- hidden employee surveillance

## Model documentation
For each production model:
- model/provider
- version
- intended use
- prohibited use
- input fields
- output fields
- evaluation dataset
- known limitations
- fairness testing
- rollback plan
