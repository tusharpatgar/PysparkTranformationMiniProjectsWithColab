# Pitch Deck Outline

## Slide 1 — The problem
Companies have employees capable of moving internally, but career decisions and internal hiring can be fragmented, opaque, and manager-dependent.

## Slide 2 — The cost
External hiring, avoidable attrition, slow internal mobility, and poor career visibility create measurable cost.

## Slide 3 — Current workflow
HRMS + manager opinion + spreadsheets + disconnected systems.

## Slide 4 — Product
Evidence-based internal career intelligence.

## Slide 5 — How it works
Employee/role data → skills/evidence → matching → readiness → decision record.

## Slide 6 — Differentiation
Not another HRMS. Focused on internal movement and evidence-backed career decisions.

## Slide 7 — Example
Show one employee moving from current role to target role with evidence and gaps.

## Slide 8 — Governance
AI recommends; humans decide; the system records evidence and review.

## Slide 9 — ROI
Internal fill rate, time saved, external hiring avoided, retention opportunity.

## Slide 10 — Market
Show competitor landscape and exact wedge.

## Slide 11 — Pilot
One department, one role family, 6–8 weeks.

## Slide 12 — Ask
Pilot/customer/design partner/funding, depending on stage.
