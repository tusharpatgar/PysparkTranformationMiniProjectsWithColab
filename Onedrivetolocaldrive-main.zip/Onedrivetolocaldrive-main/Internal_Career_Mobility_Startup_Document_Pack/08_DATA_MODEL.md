# Data Model

## Core entities
- Organization
- User
- Employee
- Department
- ManagerRelationship
- Role
- JobOpening
- Skill
- SkillEvidence
- Project
- CareerPath
- PromotionCriteria
- CriteriaVersion
- Application
- Assessment
- Decision
- DecisionReason
- Review
- Override
- AuditEvent
- LearningResource
- Opportunity

## Key principle
Separate:
1. raw source data
2. normalized data
3. AI-derived data
4. human-entered assessments
5. final decisions
6. audit records

Never overwrite the original source evidence with an AI-generated interpretation.

## Evidence model
Every inferred skill should store:
- source type
- source reference
- extraction method
- model/version if AI-derived
- confidence
- created timestamp
- reviewer status

## Multi-tenancy
Every customer-owned record must be scoped to an organization/tenant ID.
Cross-tenant access must be impossible by default.
