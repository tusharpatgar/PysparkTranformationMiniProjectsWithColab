# Security Requirements

## Identity
- MFA for privileged accounts
- SSO for enterprise customers when required
- strong session controls
- password hashing only through proven identity infrastructure

## Authorization
RBAC:
- Employee
- Manager
- HR
- Reviewer
- Admin
- Support

Use least privilege.

## Data protection
- TLS in transit
- encryption at rest
- managed secrets
- no secrets in source control
- tenant isolation
- secure file handling

## Application security
- input validation
- output encoding
- CSRF protection where applicable
- rate limiting
- dependency scanning
- secure headers
- vulnerability management

## Audit
Log:
- authentication
- privileged access
- employee-data access
- exports
- criteria changes
- assessments
- decisions
- overrides
- admin actions

## Operations
- backups
- recovery tests
- incident response
- monitoring
- alerting
- access reviews
- key rotation

## Enterprise readiness
Prepare for:
- security questionnaire
- penetration test
- ISO 27001 path if demanded
- SOC 2 path for relevant global customers
