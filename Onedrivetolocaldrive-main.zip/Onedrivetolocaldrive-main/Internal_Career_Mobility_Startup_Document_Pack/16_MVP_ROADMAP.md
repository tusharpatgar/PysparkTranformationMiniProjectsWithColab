# MVP Roadmap

## Phase 0 — Validation
Exit criteria:
- 20+ employee interviews
- 10+ HR/manager interviews
- competitor matrix
- one clearly validated problem
- at least 3 prospects willing to see a prototype

## Phase 1 — Prototype
Build:
- employee import
- role import
- skill extraction
- internal matching
- evidence view
- career-gap view

Exit:
- expert reviewers find recommendations useful

## Phase 2 — Governance MVP
Add:
- promotion criteria
- criteria versioning
- decision ledger
- review triggers
- audit events

Exit:
- pilot customer agrees to test

## Phase 3 — Paid pilot
Target:
- one department
- one role family
- 6–8 weeks

Measure:
- internal candidates identified
- internal fill opportunities
- time saved
- decision documentation
- HR adoption

## Phase 4 — Production
Only after paid validation:
- SSO
- integrations
- security hardening
- monitoring
- data lifecycle controls
- enterprise contracts

## Phase 5 — Expansion
- more role families
- learning integration
- workforce planning
- mobility analytics
- retention risk insights
- enterprise governance
