# Intellectual Property & Trade Secret Plan

## Potential IP
- product code
- data model
- skills ontology
- role/competency framework
- matching methodology
- readiness framework
- audit workflow
- evaluation datasets
- proprietary benchmarks
- integration code
- documentation
- brand/trademarks

## Trade secrets
Protect:
- customer-specific configurations
- proprietary taxonomies
- scoring logic
- evaluation datasets
- internal benchmarks
- security architecture
- sales/customer data

## Open-source policy
Maintain:
- dependency inventory
- license inventory
- approval process
- attribution records

## Patent decision
Do not assume an AI/HR workflow is patentable or worth patenting.
Before filing, get a professional patentability/strategy opinion covering:
- novelty
- inventive step
- eligible subject matter
- commercial value
- disclosure risk
- cost

## Founder ownership
All code and product work created by founders/employees/contractors should have clear IP assignment terms.
