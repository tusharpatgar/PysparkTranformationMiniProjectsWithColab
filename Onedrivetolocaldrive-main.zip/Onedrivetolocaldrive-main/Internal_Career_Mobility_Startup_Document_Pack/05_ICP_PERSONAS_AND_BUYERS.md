# ICP, Personas & Buying Committee

## Initial ICP hypothesis
Indian organizations with 500–5,000 employees, significant internal mobility, recurring skilled hiring, and mature HR operations.

## Primary buyer
CHRO / Head of People / VP HR

## Champion
Head of Talent Management / Internal Mobility / Talent Development / HR Transformation

## Operational users
- HRBP
- Talent Acquisition
- Talent Management
- Managers
- Employees

## Economic value
- reduced external hiring
- faster time-to-productivity
- improved internal fill rate
- reduced avoidable attrition
- better career transparency
- stronger decision documentation

## Buyer objections
- employee privacy
- HRIS integration
- security review
- legal risk
- AI bias
- employee trust
- manager adoption
- data quality
- procurement
- implementation effort

## Disqualifiers
Do not prioritize customers that:
- have fewer than ~200 employees for the initial product;
- have no internal mobility process;
- have no meaningful structured employee data;
- want automatic promotion/firing decisions;
- refuse human review;
- expect free custom enterprise development.
