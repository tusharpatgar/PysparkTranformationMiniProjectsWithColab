# Paid Pilot Plan

## Pilot objective
Demonstrate that the platform can improve internal candidate discovery and make career decisions more evidence-backed.

## Recommended scope
One department or one role family.

## Inputs
- anonymized or appropriately governed employee profiles
- open roles
- role competencies
- promotion criteria
- historical internal applications where available

## Deliverables
1. internal candidate map
2. skill-gap analysis
3. career-path recommendations
4. promotion-readiness framework
5. decision-governance report
6. ROI summary

## Success metrics
- internal candidate identification rate
- internal shortlist rate
- internal fill opportunities
- time-to-shortlist
- percentage of decisions with adequate evidence
- HR satisfaction
- employee satisfaction where applicable

## Pilot safeguards
- written scope
- approved data fields
- access controls
- deletion date
- named customer owner
- named vendor owner
- incident process
- no automatic employment decisions

## Commercial hypothesis
Start with a fixed-fee pilot. Price should be tested with the customer rather than assumed from market reports.
