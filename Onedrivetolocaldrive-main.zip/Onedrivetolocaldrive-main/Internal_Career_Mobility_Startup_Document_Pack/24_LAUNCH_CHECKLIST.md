# Launch Checklist

## Validation
- [ ] Problem validated
- [ ] ICP validated
- [ ] Buyer identified
- [ ] Competitor matrix complete
- [ ] Pricing hypothesis tested
- [ ] Design partner identified

## Product
- [ ] MVP PRD approved
- [ ] synthetic data test complete
- [ ] core workflow works
- [ ] evidence traceability works
- [ ] decision ledger works
- [ ] audit events work

## Security
- [ ] RBAC tested
- [ ] tenant isolation tested
- [ ] secrets secured
- [ ] backups tested
- [ ] logging enabled
- [ ] incident plan written

## Privacy/legal
- [ ] data map completed
- [ ] customer contract reviewed
- [ ] DPA reviewed
- [ ] privacy notice reviewed
- [ ] retention/deletion reviewed
- [ ] AI governance reviewed
- [ ] professional legal review completed

## Commercial
- [ ] pilot proposal
- [ ] pricing
- [ ] ROI calculator
- [ ] demo
- [ ] security questionnaire
- [ ] customer success plan

## Go/no-go
Do not move to production employee data unless:
- customer has approved the pilot;
- data-processing responsibilities are clear;
- security controls are adequate;
- legal/privacy review is complete;
- human decision-making remains in control.
