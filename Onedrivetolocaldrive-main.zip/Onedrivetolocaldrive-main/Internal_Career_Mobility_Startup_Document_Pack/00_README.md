# Internal Career Mobility Startup — Document Pack

## Purpose
This pack is a working operating system for validating and building a B2B SaaS product focused on internal career mobility, evidence-based promotion/readiness, internal hiring, and decision auditability.

## Product thesis
Help companies identify internal talent before external hiring, make career progression more transparent, and create an auditable record of important internal career decisions.

## Core principle
**AI recommends. Humans decide. The system records evidence, rationale, review, and overrides.**

## What this pack contains
1. Strategy and problem validation
2. Customer discovery
3. Product requirements
4. UX and technical planning
5. AI/data/security governance
6. Legal/commercial preparation
7. Pilot and sales materials
8. Roadmap and launch gates

## Critical warning
Do not put real employee data into the prototype until privacy, security, contractual, and data-processing requirements have been reviewed by qualified counsel/security professionals.

## Recommended sequence
Problem validation → competitor teardown → customer interviews → paid pilot → MVP → security/legal hardening → production SaaS.

## Source grounding
The original research supplied for this project identifies internal talent marketplaces, internal mobility, career pathing, succession planning, and RPO as the relevant market categories, and names global competitors including Gloat, Fuel50, Eightfold, Workday, SAP, Oracle, Phenom, Lattice and others. It also identifies adoption/data cleanliness as a potential gap. See the supplied research file for the source material.

## Current India legal reference
The Digital Personal Data Protection Act, 2023 and Digital Personal Data Protection Rules, 2025 should be treated as core legal inputs for any production handling of employee personal data. This pack is not legal advice.
