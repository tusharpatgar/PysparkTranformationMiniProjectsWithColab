# Sources & References

## User-provided research
The supplied research document was used as the starting point for the market framing, competitor categories, and internal mobility thesis.

## Official India privacy sources
- Digital Personal Data Protection Act, 2023 — India Code:
  https://www.indiacode.nic.in/handle/123456789/22037
- Digital Personal Data Protection Rules, 2025 — Ministry of Electronics and Information Technology:
  https://www.meity.gov.in/documents/act-and-policies/digital-personal-data-protection-rules-2025-gDOxUjMtQWa

## Legal note
These documents are planning templates and product-operating documents. They are not legal advice and should not be used as final legal instruments without review by qualified Indian counsel/privacy professionals.
