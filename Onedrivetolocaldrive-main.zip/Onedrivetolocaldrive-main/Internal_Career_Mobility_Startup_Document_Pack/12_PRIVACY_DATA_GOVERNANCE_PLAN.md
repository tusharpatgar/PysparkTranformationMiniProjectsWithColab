# Privacy & Data Governance Plan

## Scope
This document is a planning template, not legal advice.

The product may process employee personal data, potentially including employment, skills, performance, career, and assessment information. The legal basis, notices, roles, retention, rights handling, cross-border transfers, and contractual responsibilities must be mapped for each deployment.

## Data classification

### Public
Product documentation, public company information.

### Internal
Product configuration, non-sensitive operational information.

### Confidential
Customer workforce configuration and business data.

### Restricted
Employee personal data, performance assessments, promotion decisions, manager comments, and similar employment records.

## Data principles
- collect only what is necessary
- define purpose before collection
- minimize data
- restrict access
- encrypt in transit and at rest
- log privileged access
- define retention
- delete when no longer required
- support correction/rights processes as applicable
- separate tenants
- do not use customer data to train general models without explicit contractual/legal basis

## Required professional review
Before production:
- determine applicable DPDP obligations
- identify Data Fiduciary/Data Processor roles as applicable
- review notices and consent/legitimate-use structure
- review cross-border processing
- review retention/deletion
- review grievance handling
- review breach response
- assess whether any enhanced obligations apply

## Official references
Digital Personal Data Protection Act, 2023: India Code.
Digital Personal Data Protection Rules, 2025: MeitY.
