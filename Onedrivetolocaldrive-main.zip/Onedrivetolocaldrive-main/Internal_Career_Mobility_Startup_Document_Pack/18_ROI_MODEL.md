# ROI Model

## External hiring cost
Estimate:
- recruiter time
- agency fees
- job-board costs
- interview time
- onboarding
- time-to-productivity
- early attrition/replacement

## Internal movement value
Estimate:
- internal recruiting time
- transition time
- training/upskilling
- time-to-productivity

## Retention value
Estimate:
- replacement cost
- vacancy time
- recruiting cost
- onboarding cost

## Example formula
Potential value =
external hiring cost avoided
+ productivity/time saved
+ avoidable replacement cost
− platform and implementation cost

## Important
Do not present hypothetical savings as realized savings. Label assumptions clearly and replace them with customer data during pilots.
