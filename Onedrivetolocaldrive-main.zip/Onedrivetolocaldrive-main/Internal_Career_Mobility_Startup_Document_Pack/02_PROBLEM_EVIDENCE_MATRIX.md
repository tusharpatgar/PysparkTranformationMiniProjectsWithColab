# Problem Evidence Matrix

Use this as a live research document. Do not mark a problem as validated until you have direct evidence.

| Problem | Who experiences it? | Frequency | Severity 1-5 | Existing workaround | Cost/impact | Evidence | Validated? |
|---|---|---:|---:|---|---|---|---|
| Employees do not know next career move | Employee | | | | | | |
| Qualified internal candidates are overlooked | HR/Employee | | | | | | |
| Managers block internal transfers | Employee/HR | | | | | | |
| Promotion criteria are unclear | Employee/HR | | | | | | |
| Promotion evidence is poorly documented | HR | | | | | | |
| External hiring happens despite internal capability | TA/HR | | | | | | |
| Employees leave after stalled progression | HR | | | | | | |
| Career decisions vary significantly by manager | HR | | | | | | |
| HR cannot reconstruct why a decision was made | HR/Compliance | | | | | | |
| Existing HR tools have poor employee adoption/data quality | HR | | | | | | |

## Validation rule
A problem is validated only when:
- at least 5 independent interviews support it, OR
- customer data demonstrates it, OR
- a buyer agrees to a paid pilot specifically addressing it.

Do not confuse people saying “interesting” with validation.
