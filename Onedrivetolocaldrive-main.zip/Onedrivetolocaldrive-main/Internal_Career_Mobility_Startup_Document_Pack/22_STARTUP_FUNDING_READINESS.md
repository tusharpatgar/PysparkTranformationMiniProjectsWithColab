# Startup Funding Readiness

## Do not raise first
First prove:
- problem
- buyer
- willingness to pay
- pilot
- early ROI
- repeatability

## Investor document set
- pitch deck
- one-page summary
- financial model
- cap table
- incorporation documents
- founder agreements
- IP assignments
- customer/pilot agreements
- product roadmap
- market/competitor analysis
- security/privacy plan
- traction metrics
- pipeline
- use-of-funds plan

## Funding narrative
Problem → why now → product → wedge → validation → market → business model → moat → traction → team → use of funds.

## Use of funds
Tie every rupee to a milestone:
- product
- security
- integrations
- customer acquisition
- key hiring

Avoid raising to “build everything.”
