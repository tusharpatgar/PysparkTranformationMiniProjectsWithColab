import os
import requests
from dotenv import load_dotenv
load_dotenv()

# access token to accces the onedrive
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
#ONEDRIVE PATH
def main(): 
    ONEDRIVE_PATH = input(

        "Enter OneDrive path: "
    )

    #LOCAL PATH
    SAVE_DIR = input(
        "Enter save dir: "
    )
    os.makedirs(SAVE_DIR, exist_ok=True)



    url = (
        f"https://graph.microsoft.com/v1.0/me/drive/root:/{ONEDRIVE_PATH}"
    )

    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}"
    }

    # Retrieve the download url 
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print("Failed to access file")
        print(response.text)
        exit()

    # Metadata of the file 
    data = response.json()

    #Extract the download URL from the metadata
    download_url = data.get("@microsoft.graph.downloadUrl")

    if not download_url:
        print("No download URL found")
        exit()

    #get the filename  if not found use default name "downloaded_file"
    filename = data.get("name", "downloaded_file")

    local_path = os.path.join(SAVE_DIR, filename)

    print(f"\nDownloading: {filename}")

    file_response = requests.get(download_url)

    if file_response.status_code != 200:
        print("Download failed")
        exit()

    # save the file 
    with open(local_path, "wb") as f:
        f.write(file_response.content)

    print("\nDownload complete")
    print(f"Saved to: {local_path}")