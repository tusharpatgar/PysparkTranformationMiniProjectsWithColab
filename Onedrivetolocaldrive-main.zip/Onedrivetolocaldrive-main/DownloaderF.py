import os
import requests
from dotenv import load_dotenv
load_dotenv()
def main():
    ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")

    ONEDRIVE_FOLDER = input(
        "Enter OneDrive folder path: "
    ).strip()

    LOCAL_SAVE_DIR = input(
        "Enter local save directory: "
    ).strip()

    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}"
    }

    os.makedirs(LOCAL_SAVE_DIR, exist_ok=True)

    def download_folder(onedrive_path, local_path):

        os.makedirs(local_path, exist_ok=True)

        url = (
            f"https://graph.microsoft.com/v1.0/"
            f"me/drive/root:/{onedrive_path}:/children"
        )

        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            print(f"Failed: {onedrive_path}")
            print(response.text)
            return

        items = response.json().get("value", [])

        for item in items:

            item_name = item["name"]
            if "folder" in item:

                new_onedrive_path = (
                    f"{onedrive_path}/{item_name}"
                )

                new_local_path = os.path.join(
                    local_path,
                    item_name
                )

                print(f"\nEntering folder: {new_onedrive_path}")

                download_folder(
                    new_onedrive_path,
                    new_local_path
                )
            else:

                print(f"Downloading: {item_name}")

                download_url = item.get(
                    "@microsoft.graph.downloadUrl"
                )

                if not download_url:
                    print("No download URL")
                    continue

                file_response = requests.get(download_url)

                if file_response.status_code != 200:
                    print(f"Failed download: {item_name}")
                    continue

                save_path = os.path.join(
                    local_path,
                    item_name
                )

                with open(save_path, "wb") as f:
                    f.write(file_response.content)

                print(f"Saved: {save_path}")

    download_folder(
        ONEDRIVE_FOLDER,
        LOCAL_SAVE_DIR
    )

    print("\nAll downloads completed.")