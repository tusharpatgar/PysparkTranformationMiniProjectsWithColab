import os
import requests
from dotenv import load_dotenv
load_dotenv()

ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")

while True:
    print("1. Download a single file")
    print("2. Download an entire folder")
    print("3. Exit")

    CHOICE = int(input("Enter your choice: ").strip())
    if CHOICE == 1:
        from Downloader import main
        main()
    elif CHOICE == 2:
        from DownloaderF import main
        main()
    elif CHOICE == 3:
        print("Exiting...")
        break
    else:
        print("Invalid choice. Please try again.")
        